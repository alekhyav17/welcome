package com.niit.shops.dao;

import com.niit.shops.model.UserDetails;

public interface UserDAO {
	public boolean isValidUser(String un, String pd);

	public boolean isAdminUser(String un, String pd);
	public void addUser(UserDetails ud);
	}
