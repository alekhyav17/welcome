package com.niit.shops.service;
import com.niit.shops.dao.CategoryDAO;
import com.niit.shops.dao.ProductDAO;
import com.niit.shops.model.CategoryModel;
import com.niit.shops.model.ProductModel;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public  class CategoryServiceimpl implements CategoryService{

	@Autowired
	private CategoryDAO cakeData;
	
	public List<CategoryModel> getAllCategories() {
		// TODO Auto-generated method stub
		System.out.println("\nCategoryService-getAllCategories()");
		return cakeData.getAllCategories();
	}

	public void addCategory(CategoryModel ndm) {
		System.out.println("\nCategoryService-addCategory()");
		cakeData.addCategory(ndm); 
	}
	public CategoryModel getCategory(String did) {
		// TODO Auto-generated method stub
		System.out.println("\nCategoryService-getCategory()");
		return cakeData.getCategory(did);
	}

	public String updateCategory(CategoryModel ndm) {
		// TODO Auto-generated method stub
		cakeData.editCategory(ndm);
		return null;
	}
	public int deleteCategory(int did) {
		// TODO Auto-generated method stub
		return cakeData.delCategory(did);
	
	}
	
}
