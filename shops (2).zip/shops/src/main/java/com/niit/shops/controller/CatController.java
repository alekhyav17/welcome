package com.niit.shops.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.Gson;
import com.niit.shops.model.CategoryModel;
import com.niit.shops.model.ProductModel;
import com.niit.shops.service.CategoryService;

@Controller
	public class CatController {
		
	@Autowired
	private CategoryService categoryserv1;
		
	@Autowired
		private SessionFactory sessionFactory;  
		
	String setName = "";
	
	@RequestMapping("/categorylist")
	public ModelAndView getcategorylist(){	
		System.out.println("\n/request maped with categorylist jsp");
		ModelAndView mv = new ModelAndView("categorylist");
		return mv;
	}
		@RequestMapping("/addCat") // from admin.jsp
		public ModelAndView addCategory() {
			System.out.println("in add category controller");
			System.out.println("\nMyContoller - addcategory");
			ModelAndView mv = new ModelAndView("addCategory");
			return mv;
			//return null;
		}
		
		@RequestMapping("/addCategory") // from addProduct.jsp
	    public ModelAndView storeProduct(@RequestParam(value="CategoryId")String cid,
	    		@RequestParam(value="CategoryName")String cn,
	    		@RequestParam(value="CategoryDetails")String cdet)
	    		
	    {
	    	System.out.println("In Add category method : " + cn );
	    	CategoryModel c = new CategoryModel();
	    	c.setCategoryId(Integer.parseInt(cid));
	    	c.setCategoryName(cn);
	    	
	    	c.setCategoryDetails(cdet);
	    	 	
	    	//System.out.println("test:"+p.getDeviceName());
	    	
	    	categoryserv1.addCategory(c);
	    	ModelAndView mv = new ModelAndView("admin");
			return mv;
	    	
	    }
		
		@RequestMapping("/GsonConCategory")
		public @ResponseBody String getCatValues() {
				
			String categories="";
			System.out.println("gsonconcategory- " );
				System.out.println("gson all categories...");
				List <CategoryModel> listcategory = categoryserv1.getAllCategories();
				Gson gson = new Gson();
				categories=gson.toJson(listcategory);
			return categories;
		}
		
		@RequestMapping("/editCategoryPageReq") // from page1.jsp
		public ModelAndView editCategory(@RequestParam(value="id")String did, HttpServletRequest request) {
		//	System.out.println("id:"+req.getParameter("CategoryID"));
			System.out.println(did);
			System.out.println("\nCatContoller - editCategoryPage - " + did);
			int id = Integer.parseInt(did);
			//devserv.deleteDevice(id);
			CategoryModel nd = new CategoryModel();
			Session s = sessionFactory.openSession();
			ModelAndView mv = new ModelAndView("editCategoryPage");
			
			CategoryModel nd1 = (CategoryModel)s.get(CategoryModel.class,id);
			HttpSession session = request.getSession();
			session.setAttribute("data", nd1);				
			session.setAttribute("caid",id);
			mv.addObject("caid",did);
			mv.addObject("command",nd1);
			//String str=(String)session.getAtt
			System.out.println("\nMyContoller - editCategoryPage - " + id + " - completed");
			return mv;		
		}
		
		@RequestMapping("editCategory")
		public ModelAndView update(@ModelAttribute("shops")CategoryModel p) 
		 {
			System.out.println("Controller - editCategory ");
			categoryserv1.updateCategory(p);
			return new ModelAndView("loginSuccessAdmin");  
		 }
		
		@RequestMapping("/deleteCategory") // from page1.jsp
		public ModelAndView deleteCategory(@RequestParam(value="id")String did) {
		//	System.out.println("id:"+req.getParameter("CategoryId"));
			System.out.println(did);
			
			System.out.println("\nCatContoller - deleteCategory - " + did);
			int id = Integer.parseInt(did);
			categoryserv1.deleteCategory(id);
			System.out.println("\nCatContoller - deleteCategory - " + id + " - completed");
			ModelAndView mv = new ModelAndView("loginSuccessAdmin");		
			return mv;		
		}

}