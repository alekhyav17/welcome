package com.niit.shops.service;

import java.util.List;

import com.niit.shops.model.ProductModel;

public interface ProductService {
	public List<ProductModel> getAllCakes();
	public void addCake(ProductModel ndm);
	public ProductModel getCake(String did);
	public String updateCake(ProductModel ndm);
	public int deleteCake(int id); 
	}
