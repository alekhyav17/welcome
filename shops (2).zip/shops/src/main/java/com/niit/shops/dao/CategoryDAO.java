package com.niit.shops.dao;

import java.util.List;

import com.niit.shops.model.CategoryModel;
import com.niit.shops.model.ProductModel;

public interface CategoryDAO {
	public void addCategory(CategoryModel ndm);
	public List<CategoryModel> getAllCategories();
	public CategoryModel getCategory(String did);
	public String editCategory(CategoryModel ndm);
	public int delCategory(int did);
}
