package com.niit.shops.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.shops.model.ProductModel;

@Repository
@Transactional
public  class ProductDAOimpl implements ProductDAO{

List <ProductModel> lst = new ArrayList<ProductModel>();

ProductModel cakeData;

@Autowired
private SessionFactory sessionFactory;   

public ProductDAOimpl(){}

public void setSessionFactory(SessionFactory sessionFactory){
	this.sessionFactory=sessionFactory;
}

public Session getCurrentSession(){
	return sessionFactory.getCurrentSession();
}
public List<ProductModel> getAllCakes() {
	// TODO Auto-generated method stub
	List<ProductModel> lst;
	System.out.println("getAllCakes()");
	Session ses = sessionFactory.openSession();
	System.out.println("getAllCakes()session " + ses.isOpen());
	Query qry = ses.createQuery("from ProductModel");
	lst = qry.list();
	System.out.println(lst);
	return lst;			
}

public ProductModel getCake(String did) {
	// TODO Auto-generated method stub
			Session ses=sessionFactory.openSession();
			cakeData = (ProductModel)ses.get(ProductModel.class,did);
			return cakeData;
}



@Transactional
public void addCake(ProductModel ndm) {
	// TODO Auto-generated method stub
	Session s=sessionFactory.getCurrentSession();
	org.hibernate.Transaction t= s.beginTransaction();
	System.out.println(ndm);
	s.saveOrUpdate(ndm);
	t.commit();	
}





public String editCake(ProductModel ndm) { 
	// TODO Auto-generated method stub
	Session session = sessionFactory.openSession();
	Transaction tx = (Transaction)session.beginTransaction();
	ProductModel nd = (ProductModel)session.load(ProductModel.class,ndm.getCakeID());
	System.out.println("update dao "+ ndm.getCakeID());
	if(nd!=null){
		session.update(ndm);
		System.out.println("update dao update true");
	}
	tx.commit();
	
	return null;
}
@Transactional
public int delCake(int did) {
	
	System.out.println("delCake()in DAO is running....");
	Session session = sessionFactory.openSession();
	System.out.println("session:"+session);
	session.load(ProductModel.class, did);
	ProductModel nd = new ProductModel();
	nd.setCakeID(did);
	session.delete(nd);		
	session.flush();
	System.out.println("delcake()in DAO is running....completed");
	return did;
}
}
