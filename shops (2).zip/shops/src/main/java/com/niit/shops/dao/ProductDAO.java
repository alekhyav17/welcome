package com.niit.shops.dao;

import java.util.List;

import com.niit.shops.model.ProductModel;

public interface ProductDAO {
	public List<ProductModel> getAllCakes();
	public ProductModel getCake(String did);
	public String editCake(ProductModel ndm);
	public int delCake(int did);
		public void addCake(ProductModel ndm); 

}
