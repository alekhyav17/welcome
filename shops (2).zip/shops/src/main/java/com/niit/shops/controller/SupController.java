package com.niit.shops.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.Gson;
import com.niit.shops.model.CategoryModel;
import com.niit.shops.model.SupplierModel;
import com.niit.shops.model.SupplierModel;
import com.niit.shops.service.CategoryService;
import com.niit.shops.service.SupplierService;

@Controller
public class SupController {
	
@Autowired
private SupplierService supplierserv;
	
@Autowired
	private SessionFactory sessionFactory;  
	
String setName = "";


	@RequestMapping("/addSup") // from admin.jsp
	public ModelAndView addSupplier() {
		System.out.println("in add supplier controller");
		System.out.println("\nSupContoller - addsupplier");
		ModelAndView mv = new ModelAndView("addSupplier");
		return mv;
		//return null;
	}
	
	@RequestMapping("/addSupplier") // from addProduct.jsp
    public ModelAndView storeProduct(@RequestParam(value="SupplierId")String cid,
    		@RequestParam(value="SupplierName")String cn,
    		@RequestParam(value="SupplierDetails")String cdet)
    		
    {
    	System.out.println("In Add supplier method : " + cn );
    	SupplierModel c = new SupplierModel();
    	c.setSupplierId(Integer.parseInt(cid));
    	c.setSupplierName(cn);
    	
    	c.setSupplierDetails(cdet);
    	 	
    	//System.out.println("test:"+p.getDeviceName());
    	
    	supplierserv.addSupplier(c);
    	ModelAndView mv = new ModelAndView("admin");
		return mv;
    	
    }
	
	@RequestMapping("/GsonConSupplier")
	public @ResponseBody String getSupValues() {
			
		String suppliers="";
		System.out.println("gsonconsupplier- " );
			System.out.println("gson all suppliers...");
			List <SupplierModel> listsupplier = supplierserv.getAllSuppliers();
			Gson gson = new Gson();
			suppliers=gson.toJson(listsupplier);
		return suppliers;
	}
	@RequestMapping("/supplierlist")
	public ModelAndView getsupplierlist(){	
		System.out.println("\n/request maped with supplierlist jsp");
		ModelAndView mv = new ModelAndView("supplierlist");
		return mv;
	}
	@RequestMapping("/editSupplierPageReq") // from page1.jsp
	public ModelAndView editSupplier(@RequestParam(value="id")String did, HttpServletRequest request) {
	//	System.out.println("id:"+req.getParameter("SupplierID"));
		System.out.println(did);
		System.out.println("\nSupContoller - editSupplierPage - " + did);
		int id = Integer.parseInt(did);
		//devserv.deleteDevice(id);
		SupplierModel nd = new SupplierModel();
		Session s = sessionFactory.openSession();
		ModelAndView mv = new ModelAndView("editSupplierPage");
		
		SupplierModel nd1 = (SupplierModel)s.get(SupplierModel.class,id);
		HttpSession session = request.getSession();
		session.setAttribute("data", nd1);				
		session.setAttribute("caid",id);
		mv.addObject("caid",did);
		mv.addObject("command",nd1);
		//String str=(String)session.getAtt
		System.out.println("\nSupContoller - editSupplierPage - " + id + " - completed");
		return mv;		
	}
	@RequestMapping("editSupplier")
	public ModelAndView update(@ModelAttribute("shops")SupplierModel p) 
	 {
		System.out.println("Controller - editSupplier ");
		supplierserv.updateSupplier(p);
		return new ModelAndView("admin");  
	 
	}
	
	@RequestMapping("/deleteSupplier") // from page1.jsp
	public ModelAndView deleteSupplier(@RequestParam(value="id")String did) {
	//	System.out.println("id:"+req.getParameter("SupplierId"));
		System.out.println(did);
		
		System.out.println("\nSupContoller - deleteSupplier - " + did);
		int id = Integer.parseInt(did);
		supplierserv.deleteSupplier(id);
		System.out.println("\nSupContoller - deleteSupplier - " + id + " - completed");
		ModelAndView mv = new ModelAndView("admin");		
		return mv;		
	}
}
