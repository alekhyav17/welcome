package com.niit.shops.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.Gson;
import com.niit.shops.dao.UserDAO;
import com.niit.shops.dao.UserDAOimpl;
import com.niit.shops.model.CategoryModel;
import com.niit.shops.model.ProductModel;
import com.niit.shops.model.UserDetails;
import com.niit.shops.service.CategoryService;
import com.niit.shops.service.CategoryServiceimpl;
import com.niit.shops.service.ProductService;

@Controller
public class MyController {
	
	@Autowired
	private ProductService caserv;
	
	@Autowired
	private SessionFactory sessionFactory;  

	@Autowired
	private CategoryService catserv1;

	String setName = "";
	//NetworkDevDAO  = null;
	
	
	
	@RequestMapping("/GsonConCategory1")
	public @ResponseBody String getCatValues() {
	    //categoryserv =new CategoryServiceimpl() ;
		String categories="";
		System.out.println("gsonconcategory- " );
			System.out.println("gson all categories...");
			List <CategoryModel> listcategory = catserv1.getAllCategories();
			Gson gson = new Gson();
			 categories=gson.toJson(listcategory);
		return categories;
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	@RequestMapping("/")
	public ModelAndView getFirstPage(){	
		System.out.println("\n/request maped with welcome jsp");
		ModelAndView mv = new ModelAndView("welcome");
		return mv;
	}	
	@RequestMapping("/product")
	public ModelAndView getproduct(){	
		System.out.println("\n/request maped with product jsp");
		ModelAndView mv = new ModelAndView("product");
		return mv;
	}
	@RequestMapping("/frontpage")
	public ModelAndView getfrontpage(){	
		System.out.println("\n/request maped with frontpage jsp");
		ModelAndView mv = new ModelAndView("frontpage");
		return mv;
	}
	@RequestMapping("/loginSuccessAdmin")
	public ModelAndView getadminpage(){	
		System.out.println("\n/request maped with loginsuccesspage jsp");
		ModelAndView mv = new ModelAndView("loginSuccessAdmin");
		return mv;
	}
	@RequestMapping("/loginSuccessUser")
	public ModelAndView getuserpage(){	
		System.out.println("\n/request maped with loginsuccessuser jsp");
		ModelAndView mv = new ModelAndView("loginSuccessUser");
		return mv;
	}

	
	@RequestMapping("/page0")
	public ModelAndView getPage1(){	
		System.out.println("\n/request maped with page0 jsp");
		ModelAndView mv = new ModelAndView("page0");
		return mv;
	}
	@RequestMapping("/contact")
	public ModelAndView getcontactPage(){	
		System.out.println("\n/request maped with contact jsp");
		ModelAndView mv = new ModelAndView("contact");
		return mv;
	}
	@RequestMapping("/categories")
	public ModelAndView getcategories(){	
		System.out.println("\n/request maped with categories jsp");
		ModelAndView mv = new ModelAndView("categories");
		return mv;
	}
	
	
	@RequestMapping("/cake")
	public ModelAndView AllProductCode(
			@RequestParam(value = "name", required = false, defaultValue = "CAKE") String name) {
		System.out.println("\n/request maped with page1 jsp(alias cake)");
		ModelAndView allprod = new ModelAndView("page1");
		 setName = name;
		System.out.println(setName);
		return allprod;
	}


	@RequestMapping("/GsonCon")
	public @ResponseBody String getValues() {
			
		//ndd = new NetworkDevDAOImpl();
		String cakes="";
		System.out.println("gsoncon - " + setName);
		if("allcake".equals(setName)){
			System.out.println("gson all cakes...");
			List <ProductModel> listcake = caserv.getAllCakes();
			Gson gson = new Gson();
			cakes=gson.toJson(listcake);
		}
		else{		
			System.out.println("gson one cakes...");
			ProductModel nd = ProductModel.getCake(setName);
			List <ProductModel> ld = new ArrayList<ProductModel>();
			ld.add(nd);
			Gson gson=new Gson();
			cakes=gson.toJson(ld);				
		}
		return cakes;
	}
		@RequestMapping("/GsonConAdmin")
		public  @ResponseBody String getDataforAdmin() {
				
			//ndd = new NetworkDevDAOImpl();
			String cas="";	
		
				System.out.println("gson all cakes...Admin");
				List <ProductModel> listca = caserv.getAllCakes();
				Gson gson = new Gson();
				cas=gson.toJson(listca);
			
			return cas;
		}
		
		@RequestMapping("/GsonConUser")
		public  @ResponseBody String getDataforUser() {
				
			//ndd = new NetworkDevDAOImpl();
			String cas="";	
		
				System.out.println("gson all cakes...User");
				List <ProductModel> listca = caserv.getAllCakes();
				Gson gson = new Gson();
				cas=gson.toJson(listca);
			
			return cas;
		}
		
	
	
	
	@RequestMapping("/addCa") // from welcome.jsp
	public ModelAndView addDevice() {
		System.out.println("in add ca controller");
		System.out.println("\nMyContoller - addCa");
		ModelAndView mv = new ModelAndView("addCake");
		return mv;
		//return null;
	}
	
	@RequestMapping("/addCake") // from addCake.jsp
    public ModelAndView storeProduct(@RequestParam(value="CakeId")String did,@RequestParam(value="CakeName")String dn,
    		@RequestParam(value="CakeCategory")String dcat,@RequestParam(value="CakeDetails")String ddet,
    		@RequestParam(value="CakePrice")String dprice,
    		@RequestParam(value="CakePhotoURL")String durl)
    {
    	System.out.println("In Add cake method : " + dn );
    	ProductModel p = new ProductModel();
    	p.setCakeID(Integer.parseInt(did));
    	p.setCakeName(dn);
    	p.setCakeCategory(dcat);
    	p.setCakeDetails(ddet);
    	p.setCakePrice(Integer.parseInt(dprice));
    	p.setCakePhotoURL(durl);    	
    	//System.out.println("test:"+p.getCakeName());
    	
    	caserv.addCake(p);
    	//ModelAndView mv = new ModelAndView("page1");		
    	ModelAndView mv = new ModelAndView("admin");
		return mv;
    }
    
	@RequestMapping("register")
	public ModelAndView registerUser(){
		ModelAndView mv = new ModelAndView("userRegistration1");
		
		return mv;
	}

	//registerUser
	@RequestMapping("registerUser")
	public ModelAndView regUser(@RequestParam(value="userid")String uid,@RequestParam(value="password")String pwd,
    		@RequestParam(value="emailid")String email,@RequestParam(value="mobilenumber")String mobile,
    		@RequestParam(value="address")String addr,@RequestParam(value="city")String cit,
    		@RequestParam(value="state")String st,@RequestParam(value="country")String cnt )
	{
		System.out.println("regusteruser");
		UserDetails ud = new UserDetails();
		
		ud.setUserId(uid);
		ud.setPassword(pwd);
		ud.setAdmin(false);
		ud.setStatus("valid");
		ud.setEmailId(email);
		ud.setMobileNo(mobile);
		ud.setAddress(addr);
		ud.setCity(cit);
		ud.setState(st);
		ud.setCountry(cnt);		
		
		UserDAO udao = new UserDAOimpl(sessionFactory);
		udao.addUser(ud);
		
		
		ModelAndView mv = new ModelAndView("loginSuccessUser");
		
		return mv;
	}
	@RequestMapping("/loginpage") // from welcome.jsp
	public ModelAndView loginpage() {
		System.out.println("\nMyContoller - loginpage");
		ModelAndView mv = new ModelAndView("login");
		return mv;
		//return null;
	}
    
	@RequestMapping("/logincheck") // from login.jsp
	public ModelAndView logincheck(@RequestParam(value="userid")String userid,@RequestParam(value="pwd")String passwd) {
		System.out.println("\nMyContoller - logincheck");
		ModelAndView mv;
		System.out.println("\nMyContoller - /loginCheck - before session factory");
		UserDAO ud = new UserDAOimpl(sessionFactory);
		System.out.println("\nMyContoller - /loginCheck - after session factory");
		
		if(ud.isValidUser(userid,passwd)==true && ud.isAdminUser(userid,passwd)==true ) {
			System.out.println("login ok");
			mv=new ModelAndView("admin");
		}
		else if(ud.isValidUser(userid,passwd)==true ) {
			System.out.println("login ok");
			mv=new ModelAndView("user");
		}
		else {
			System.out.println("login not ok");			
			mv=new ModelAndView("loginerror");
		}
		return mv;	
	}
	@RequestMapping("/editCakePageReq") // from page1.jsp
	public ModelAndView editCake(@RequestParam(value="id")String did, HttpServletRequest request) {
	//	System.out.println("id:"+req.getParameter("CakeID"));
		System.out.println(did);
		System.out.println("\nMyContoller - editCakePage - " + did);
		int id = Integer.parseInt(did);
		//devserv.deleteDevice(id);
		ProductModel nd = new ProductModel();
		Session s = sessionFactory.openSession();
		ModelAndView mv = new ModelAndView("editCakePage");
		
		ProductModel nd1 = (ProductModel)s.get(ProductModel.class,id);
		HttpSession session = request.getSession();
		session.setAttribute("data", nd1);				
		session.setAttribute("caid",id);
		mv.addObject("caid",did);
		mv.addObject("command",nd1);
		//String str=(String)session.getAtt
		System.out.println("\nMyContoller - editCakePage - " + id + " - completed");
		return mv;		
	}
	
	@RequestMapping("editCake")
	public ModelAndView update(@ModelAttribute("shops")ProductModel p) 
	 {
		System.out.println("Controller - editCake ");
		caserv.updateCake(p);
		return new ModelAndView("loginSuccessAdmin");  
	 }
	
	@RequestMapping("/deleteCake") // from page1.jsp
	public ModelAndView deleteCake(@RequestParam(value="id")String did) {
	//	System.out.println("id:"+req.getParameter("DeviceId"));
		System.out.println(did);
		
		System.out.println("\nMyContoller - deleteCake - " + did);
		int id = Integer.parseInt(did);
		caserv.deleteCake(id);
		System.out.println("\nMyContoller - deleteCake - " + id + " - completed");
		ModelAndView mv = new ModelAndView("page1");		
		return mv;		
	}


}