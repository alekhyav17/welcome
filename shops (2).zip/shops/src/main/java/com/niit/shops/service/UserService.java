package com.niit.shops.service;

import com.niit.shops.model.UserDetails;

public interface UserService {
	public boolean isValidUser(String un, String pd);
	public void addUser(UserDetails ud);
}
