package com.niit.shops.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.niit.shops.dao.CategoryDAO;
import com.niit.shops.dao.SupplierDAO;
import com.niit.shops.model.CategoryModel;
import com.niit.shops.model.SupplierModel;

@Service
public  class SupplierServiceimpl implements SupplierService{

	@Autowired
	private SupplierDAO cakeData;
	
	

	public void addSupplier(SupplierModel ndm) {
		System.out.println("\nSupplierService-addSupplier()");
		cakeData.addSupplier(ndm); 
	}
	public List<SupplierModel> getAllSuppliers() {
		// TODO Auto-generated method stub
		System.out.println("\nSupplierService-getAllSuppliers()");
		return cakeData.getAllSuppliers();
	}
	public SupplierModel getSupplier(String did) {
		// TODO Auto-generated method stub
		System.out.println("\nSupplierService-getSupplier()");
		return cakeData.getSupplier(did);
	}
	public String updateSupplier(SupplierModel ndm) {
		// TODO Auto-generated method stub
		cakeData.editSupplier(ndm);
		return null;
	}
	public int deleteSupplier(int did) {
		// TODO Auto-generated method stub
		return cakeData.delSupplier(did);
	
	}
}
