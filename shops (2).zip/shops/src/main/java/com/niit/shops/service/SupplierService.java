package com.niit.shops.service;


import java.util.List;

import com.niit.shops.model.CategoryModel;
import com.niit.shops.model.SupplierModel;

public interface SupplierService {
	public void addSupplier(SupplierModel ndm);
	public List<SupplierModel> getAllSuppliers();
	public SupplierModel getSupplier(String did);
	public String updateSupplier(SupplierModel ndm);
	public int deleteSupplier(int id); 
}
