package com.niit.shops.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.shops.model.CategoryModel;
import com.niit.shops.model.SupplierModel;

@Repository
@Transactional
public  class SupplierDAOimpl implements SupplierDAO{

	List <SupplierModel> lst = new ArrayList<SupplierModel>();

SupplierModel cakeData;

@Autowired
private SessionFactory sessionFactory;   

public SupplierDAOimpl(){}

public void setSessionFactory(SessionFactory sessionFactory){
	this.sessionFactory=sessionFactory;
}

	@Transactional
	public void addSupplier(SupplierModel ndm) {
		// TODO Auto-generated method stub
		Session s=sessionFactory.getCurrentSession();
		Transaction t=s.beginTransaction();
		System.out.println(ndm);
		s.saveOrUpdate(ndm);
		t.commit();	
	}

	public List<SupplierModel> getAllSuppliers() {
		// TODO Auto-generated method stub
		List<SupplierModel> lst;
		System.out.println("getAllSuppliers()");
		Session ses = sessionFactory.openSession();
		System.out.println("getAllSuppliers()session " + ses.isOpen());
		Query qry = ses.createQuery("from SupplierModel");
		lst = qry.list();
		System.out.println(lst);
		return lst;			
	}

	public SupplierModel getSupplier(String did) {
		// TODO Auto-generated method stub
				Session ses=sessionFactory.openSession();
				cakeData = (SupplierModel)ses.get(SupplierModel.class,did);
				return cakeData;
	}
	
	public String editSupplier(SupplierModel ndm) { 
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		Transaction tx = (Transaction)session.beginTransaction();
		SupplierModel nd = (SupplierModel)session.load(SupplierModel.class,ndm.getSupplierId());
		System.out.println("update dao "+ ndm.getSupplierId());
		if(nd!=null){
			session.update(ndm);
			System.out.println("update dao update true");
		}
		tx.commit();
		
		return null;
	}
	
	@Transactional
	public int delSupplier(int did) {
		
		System.out.println("delSupplier()in DAO is running....");
		Session session = sessionFactory.openSession();
		System.out.println("session:"+session);
		session.load(SupplierModel.class, did);
		SupplierModel nd = new SupplierModel();
		nd.setSupplierId(did);
		session.delete(nd);		
		session.flush();
		System.out.println("delsupplier()in DAO is running....completed");
		return did;
	}

}
