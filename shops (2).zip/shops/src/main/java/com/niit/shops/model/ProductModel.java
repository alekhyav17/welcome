package com.niit.shops.model;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Table(name="ProductTable")
@Component
public class ProductModel {
	@Id 
	private int CakeID;
	private String CakeName;
	private String CakeCategory;
	private String CakeDetails; 
	private int CakePrice;	
	private String CakePhotoURL;
	public int getCakeID() {
		return CakeID;
	}
	public void setCakeID(int i) {
		CakeID = i;
	}
	public String getCakeName() {
		return CakeName;
	}
	public void setCakeName(String cakeName) {
		CakeName = cakeName;
	}
	public String getCakeCategory() {
		return CakeCategory;
	}
	public void setCakeCategory(String cakeCategory) {
		CakeCategory = cakeCategory;
	}
	public String getCakeDetails() {
		return CakeDetails;
	}
	public void setCakeDetails(String cakeDetails) {
		CakeDetails = cakeDetails;
	}
	public int getCakePrice() {
		return CakePrice;
	}
	public void setCakePrice(int cakePrice) {
		CakePrice = cakePrice;
	}
	public String getCakePhotoURL() {
		return CakePhotoURL;
	}
	public void setCakePhotoURL(String cakePhotoURL) {
		CakePhotoURL = cakePhotoURL;
	}
	public static ProductModel getCake(String setName) {
		// TODO Auto-generated method stub
		return null;
	}
	
}
