package com.niit.shops.service;

import java.util.List;

import com.niit.shops.model.CategoryModel;
import com.niit.shops.model.ProductModel;

public interface CategoryService {
	public void addCategory(CategoryModel ndm);
	public List<CategoryModel> getAllCategories();
	public CategoryModel getCategory(String did);
	public String updateCategory(CategoryModel ndm);
	public int deleteCategory(int id); 
}
