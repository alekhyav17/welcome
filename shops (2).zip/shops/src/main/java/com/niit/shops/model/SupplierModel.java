package com.niit.shops.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="SupplierTable")
public class SupplierModel {
	@Id 
	private int SupplierId;
	private String SupplierName;
	private String SupplierDetails;
	public int getSupplierId() {
		return SupplierId;
	}
	public void setSupplierId(int supplierId) {
		SupplierId = supplierId;
	}
	public String getSupplierName() {
		return SupplierName;
	}
	public void setSupplierName(String supplierName) {
		SupplierName = supplierName;
	}
	public String getSupplierDetails() {
		return SupplierDetails;
	}
	public void setSupplierDetails(String supplierDetails) {
		SupplierDetails = supplierDetails;
	}

}
