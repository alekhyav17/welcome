package com.niit.shops.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.shops.model.CategoryModel;
import com.niit.shops.model.ProductModel;

@Repository
@Transactional
public  class CategoryDAOimpl implements CategoryDAO{

List <CategoryModel> lst = new ArrayList<CategoryModel>();

CategoryModel cakeData;

@Autowired
private SessionFactory sessionFactory;   

public CategoryDAOimpl(){}

public void setSessionFactory(SessionFactory sessionFactory){
	this.sessionFactory=sessionFactory;
}

public Session getCurrentSession(){
	return sessionFactory.getCurrentSession();
}
public List<CategoryModel> getAllCategories() {
	// TODO Auto-generated method stub
	List<CategoryModel> lst;
	System.out.println("getAllCategories()");
	Session ses = sessionFactory.openSession();
	System.out.println("getAllCategories()session " + ses.isOpen());
	Query qry = ses.createQuery("from CategoryModel");
	lst = qry.list();
	System.out.println(lst);
	return lst;			
}

public CategoryModel getCategory(String did) {
	// TODO Auto-generated method stub
			Session ses=sessionFactory.openSession();
			cakeData = (CategoryModel)ses.get(CategoryModel.class,did);
			return cakeData;
}

@Transactional
	public void addCategory(CategoryModel ndm) {
		// TODO Auto-generated method stub
		Session s=sessionFactory.getCurrentSession();
		Transaction t=s.beginTransaction();
		System.out.println(ndm);
		s.saveOrUpdate(ndm);
		t.commit();	
	}

public String editCategory(CategoryModel ndm) { 
	// TODO Auto-generated method stub
	Session session = sessionFactory.openSession();
	Transaction tx = (Transaction)session.beginTransaction();
	CategoryModel nd = (CategoryModel)session.load(CategoryModel.class,ndm.getCategoryId());
	System.out.println("update dao "+ ndm.getCategoryId());
	if(nd!=null){
		session.update(ndm);
		System.out.println("update dao update true");
	}
	tx.commit();
	
	return null;
}
@Transactional
public int delCategory(int did) {
	
	System.out.println("delCategory()in DAO is running....");
	Session session = sessionFactory.openSession();
	System.out.println("session:"+session);
	session.load(CategoryModel.class, did);
	CategoryModel nd = new CategoryModel();
	nd.setCategoryId(did);
	session.delete(nd);		
	session.flush();
	System.out.println("delcategory()in DAO is running....completed");
	return did;
}


}