package com.niit.shops.service;
import com.niit.shops.dao.ProductDAO;
import com.niit.shops.model.ProductModel;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public  class ProductServiceimpl implements ProductService{

	@Autowired
	private ProductDAO cakeData;
	
	public List<ProductModel> getAllCakes() {
		// TODO Auto-generated method stub
		System.out.println("\nProductService-getAllCake()");
		return cakeData.getAllCakes();
	}

	public void addCake(ProductModel ndm) {
		System.out.println("\nProductService-addCake()");
		cakeData.addCake(ndm); 
	}
	public ProductModel getCake(String did) {
		// TODO Auto-generated method stub
		System.out.println("\nProductService-getCake()");
		return cakeData.getCake(did);
	}

	public String updateCake(ProductModel ndm) {
		// TODO Auto-generated method stub
		cakeData.editCake(ndm);
		return null;
	}
	public int deleteCake(int did) {
		// TODO Auto-generated method stub
		return cakeData.delCake(did);
	
	}
	
}
