package com.niit.shops.dao;

import java.util.List;

import com.niit.shops.model.CategoryModel;
import com.niit.shops.model.SupplierModel;

public interface SupplierDAO {
	public void addSupplier(SupplierModel ndm);
	public List<SupplierModel> getAllSuppliers();
	public SupplierModel getSupplier(String did);
	public String editSupplier(SupplierModel ndm);
	public int delSupplier(int did);
}
