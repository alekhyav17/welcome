#######  USER TABLE

create table UserDetails
(
	UserId char(10),
	Password char(20),
	isAdmin boolean,
	Status char(10),
	EmailId char(20),
	MobileNo char(14),
	Address char(30),
	City char(20),
	State char(20),
	Country char(20)
)

insert into UserDetails values('admin','12345',true,'valid','admin@a.com','423432','Narayanguda','Hyd','AP','Ind')
insert into UserDetails values('user1','12345',false,'valid','abcd@a.com','423432','Plot 4','Hyd','AP','Ind')

select * from userdetails

#############
