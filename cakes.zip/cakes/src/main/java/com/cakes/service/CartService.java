package com.cakes.service;

import com.cakes.model.Cart;

public interface CartService {

    Cart getCartById(int cartId);

    void update(Cart cart);
}
